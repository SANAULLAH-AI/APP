import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, TouchableOpacity, FlatList, ActivityIndicator, Appearance, KeyboardAvoidingView, Platform, Animated, Switch } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { AntDesign, MaterialIcons } from '@expo/vector-icons';

export default function App() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [darkMode, setDarkMode] = useState(Appearance.getColorScheme() === 'dark');
  const fadeAnim = useState(new Animated.Value(0))[0];

  useEffect(() => {
    loadMessages();
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 500,
      useNativeDriver: true,
    }).start();
  }, []);

  const loadMessages = async () => {
    try {
      const storedMessages = await AsyncStorage.getItem('chatHistory');
      if (storedMessages) setMessages(JSON.parse(storedMessages));
    } catch (error) {
      console.error("Error loading messages:", error);
    }
  };

  const saveMessages = async (newMessages) => {
    try {
      await AsyncStorage.setItem('chatHistory', JSON.stringify(newMessages));
    } catch (error) {
      console.error("Error saving messages:", error);
    }
  };

  const clearChat = async () => {
    setMessages([]);
    await AsyncStorage.removeItem('chatHistory');
  };

  const sendMessage = async () => {
    if (!input.trim()) return;
    const newMessages = [...messages, { role: 'user', content: input }];
    setMessages(newMessages);
    saveMessages(newMessages);
    setInput('');
    setLoading(true);

    const botReply = await fetchAIResponse(input);
    const updatedMessages = [...newMessages, { role: 'assistant', content: botReply }];
    setMessages(updatedMessages);
    saveMessages(updatedMessages);
    setLoading(false);
  };

  const fetchAIResponse = async (query) => {
    const lowerQuery = query.toLowerCase();
    if (lowerQuery.includes("your name")||lowerQuery.includes("name")) {
      return "My name is Sanaullah AI.";
    } else if (lowerQuery.includes("your age") || lowerQuery.includes("age")) {
      return "I am 21 years old.";
    } else if (lowerQuery.includes("tell me about yourself") || lowerQuery.includes("about yourself")||lowerQuery.includes("about you")) {
      return "I am a large language model, trained by SANAULLAH. I can process information and respond to a wide range of prompts and questions, generating text in response. My name is Sunny AI. I am 21 years old. Trained by Sanaullah, a student of BSCS in Abasyn University Islamabad.";
    } else if (lowerQuery.includes("your university") || lowerQuery.includes("where you study") || lowerQuery.includes("your study") || lowerQuery.includes("what do you do")) {
      return "I study at Abasyn University Islamabad Campus.";
    } else if (lowerQuery.includes("your study") || lowerQuery.includes("what do you study")) {
      return "I am a student of BSCS.";
    }
    
    const apiKey = 'AIzaSyCUWYUKcqkkFWwzZ7tootHpfHWFZzqU_lg';
    const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`;

    try {
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          contents: [{ parts: [{ text: query }] }],
        }),
      });
      const data = await response.json();
      return data.candidates?.[0]?.content?.parts?.[0]?.text || 'No response received.';
    } catch (error) {
      console.error("Error fetching AI response:", error);
      return 'Error fetching response. Please try again later.';
    }
  };

  return (
    <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ flex: 1, padding: 20, backgroundColor: darkMode ? '#121212' : '#f5f5f5' }}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
        <Text style={{ color: darkMode ? 'white' : 'black', fontSize: 22, fontWeight: 'bold' }}>Chatbot</Text>
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
          <TouchableOpacity onPress={clearChat} style={{ marginRight: 10 }}>
            <MaterialIcons name='delete' size={28} color={darkMode ? 'white' : 'black'} />
          </TouchableOpacity>
          <Switch value={darkMode} onValueChange={() => setDarkMode(!darkMode)} />
        </View>
      </View>
      <Animated.View style={{ opacity: fadeAnim, flex: 1 }}>
        <FlatList
          data={messages}
          keyExtractor={(_, index) => index.toString()}
          renderItem={({ item }) => (
            <View style={{ 
              alignSelf: item.role === 'user' ? 'flex-end' : 'flex-start',
              marginVertical: 5,
              backgroundColor: item.role === 'user' ? '#007AFF' : '#E5E5EA',
              padding: 12,
              borderRadius: 18,
              maxWidth: '75%',
              shadowColor: '#000',
              shadowOpacity: 0.1,
              shadowOffset: { width: 0, height: 2 },
              shadowRadius: 4,
              elevation: 5,
            }}>
              <Text style={{ color: item.role === 'user' ? 'white' : 'black', fontSize: 16 }}>{item.content}</Text>
            </View>
          )}
        />
      </Animated.View>

      {loading && <ActivityIndicator size='large' color='#007AFF' style={{ marginVertical: 10 }} />}
      
      <View style={{ 
        flexDirection: 'row', 
        alignItems: 'center', 
        padding: 14, 
        backgroundColor: darkMode ? '#1e1e1e' : 'white', 
        borderRadius: 30, 
        marginBottom: 10,
        shadowColor: '#000',
        shadowOpacity: 0.2,
        shadowOffset: { width: 0, height: 4 },
        shadowRadius: 6,
        elevation: 8,
      }}>
        <TextInput
          style={{ flex: 1, padding: 10, fontSize: 16, color: darkMode ? 'white' : 'black' }}
          placeholder='Type a message...'
          placeholderTextColor={darkMode ? '#888' : '#555'}
          value={input}
          onChangeText={setInput}
        />
        <TouchableOpacity onPress={sendMessage} style={{ marginLeft: 10 }}>
          <AntDesign name='arrowup' size={32} color='#007AFF' />
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}