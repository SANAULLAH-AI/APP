
import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import * as ScreenOrientation from 'expo-screen-orientation';

export default function App() {
  const [isPortrait, setIsPortrait] = useState(true);
  const [isLocked, setIsLocked] = useState(false);

  useEffect(() => {
    const lockOrientationsAsync = async () => {
      try {
        await ScreenOrientation.unlockAsync();
        if (isPortrait) {
          await ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.PORTRAIT_UP);
        } else {
          await ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.LANDSCAPE_RIGHT);
        }
      } catch (error) {
        console.error('Error changing orientation:', error);
      }
    };
    lockOrientationsAsync();
  }, [isPortrait]);

  const toggleOrientation = () => {
    if (!isLocked) {
      setIsPortrait(!isPortrait);
    }
  };

  const toggleLock = () => {
    setIsLocked(!isLocked);
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerText}>Orientation Changer</Text>
      </View>
      <View style={styles.content}>
        <Text style={styles.orientationText}>
          Current Orientation: {isPortrait ? 'Portrait' : 'Landscape'}
        </Text>
        <TouchableOpacity style={styles.toggleButton} onPress={toggleOrientation}>
          <Text style={styles.toggleButtonText}>FLIP</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.lockButton} onPress={toggleLock}>
          <Text style={styles.lockButtonText}>{isLocked ? 'UNLOCK' : 'LOCK'}</Text>
        </TouchableOpacity>
      </View>
      <View style={styles.footer}>
        <Text style={styles.footerText}>Made with Expo</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  header: {
    backgroundColor: '#007BFF',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
  },
  headerText: {
    fontSize: 24,
    color: '#fff',
  },
  content: {
    padding: 20,
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  orientationText: {
    fontSize: 20,
    marginBottom: 20,
  },
  toggleButton: {
    backgroundColor: '#007BFF',
    padding: 10,
    borderRadius: 5,
    marginBottom: 10,
  },
  toggleButtonText: {
    fontSize: 18,
    color: '#fff',
  },
  lockButton: {
    backgroundColor: '#FF9800',
    padding: 10,
    borderRadius: 5,
  },
  lockButtonText: {
    fontSize: 18,
    color: '#fff',
  },
  footer: {
    padding: 10,
    backgroundColor: '#007BFF',
    borderTopWidth: 1,
    borderTopColor: '#ccc',
  },
  footerText: {
    fontSize: 16,
    color: '#fff',
  },
});

