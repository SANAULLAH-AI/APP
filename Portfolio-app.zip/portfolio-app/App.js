import React, { useState, useEffect } from 'react';
import { NavigationContainer, DefaultTheme, DarkTheme } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, Image, ActivityIndicator, TextInput, Switch, Animated, FlatList, Alert } from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { AntDesign, MaterialIcons } from '@expo/vector-icons';

// Create a stack navigator
const Stack = createStackNavigator();

// Chatbot Component
const ChatbotScreen = () => {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [darkMode, setDarkMode] = useState(false);
  const fadeAnim = useState(new Animated.Value(0))[0];

  useEffect(() => {
    loadMessages();
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 500,
      useNativeDriver: true,
    }).start();
  }, [fadeAnim]); // Added fadeAnim to dependency array

  const loadMessages = async () => {
    try {
      const storedMessages = await AsyncStorage.getItem('chatHistory');
      if (storedMessages) setMessages(JSON.parse(storedMessages));
    } catch (error) {
      console.error("Error loading messages:", error);
    }
  };

  const saveMessages = async (newMessages) => {
    try {
      await AsyncStorage.setItem('chatHistory', JSON.stringify(newMessages));
    } catch (error) {
      console.error("Error saving messages:", error);
    }
  };

  const clearChat = async () => {
    setMessages([]);
    await AsyncStorage.removeItem('chatHistory');
  };

  const sendMessage = async () => {
    if (!input.trim()) return;
    const newMessages = [...messages, { role: 'user', content: input }];
    setMessages(newMessages);
    saveMessages(newMessages);
    setInput('');
    setLoading(true);

    const botReply = await fetchAIResponse(input);
    const updatedMessages = [...newMessages, { role: 'assistant', content: botReply }];
    setMessages(updatedMessages);
    saveMessages(updatedMessages);
    setLoading(false);
  };

  const fetchAIResponse = async (query) => {
    const lowerQuery = query.toLowerCase();
    if (lowerQuery.includes("your name") || lowerQuery.includes("name")) {
      return "My name is Sanaullah AI.";
    } else if (lowerQuery.includes("your age") || lowerQuery.includes("age")) {
      return "I am 21 years old.";
    } else if (lowerQuery.includes("tell me about yourself") || lowerQuery.includes("about yourself") || lowerQuery.includes("about you")) {
      return "I am a large language model, trained by SANAULLAH. I can process information and respond to a wide range of prompts and questions, generating text in response. My name is Sunny AI. I am 21 years old. Trained by Sanaullah, a student of BSCS in Abasyn University Islamabad.";
    } else if (lowerQuery.includes("your university") || lowerQuery.includes("where you study") || lowerQuery.includes("your study") || lowerQuery.includes("what do you do")) {
      return "I study at Abasyn University Islamabad Campus.";
    } else if (lowerQuery.includes("your study") || lowerQuery.includes("what do you study")) {
      return "I am a student of BSCS.";
    }

    const apiKey = 'AIzaSyCUWYUKcqkkFWwzZ7tootHpfHWFZzqU_lg';
    const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`;

    try {
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          contents: [{ parts: [{ text: query }] }],
        }),
      });
      const data = await response.json();
      return data.candidates?.[0]?.content?.parts?.[0]?.text || 'No response received.';
    } catch (error) {
      console.error("Error fetching AI response:", error);
      return 'Error fetching response. Please try again later.';
    }
  };

  return (
    <View style={{ flex: 1, padding: 20, backgroundColor: darkMode ? '#121212' : '#f5f5f5' }}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
        <Text style={{ color: darkMode ? 'white' : 'black', fontSize: 22, fontWeight: 'bold' }}>Chatbot</Text>
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
          <TouchableOpacity onPress={clearChat} style={{ marginRight: 10 }}>
            <MaterialIcons name='delete' size={28} color={darkMode ? 'white' : 'black'} />
          </TouchableOpacity>
          <Switch value={darkMode} onValueChange={() => setDarkMode(!darkMode)} />
        </View>
      </View>
      <Animated.View style={{ opacity: fadeAnim, flex: 1 }}>
        <FlatList
          data={messages}
          keyExtractor={(_, index) => index.toString()}
          renderItem={({ item }) => (
            <View style={{
              alignSelf: item.role === 'user' ? 'flex-end' : 'flex-start',
              marginVertical: 5,
              backgroundColor: item.role === 'user' ? '#007AFF' : '#E5E5EA',
              padding: 12,
              borderRadius: 18,
              maxWidth: '75%',
              shadowColor: '#000',
              shadowOpacity: 0.1,
              shadowOffset: { width: 0, height: 2 },
              shadowRadius: 4,
              elevation: 5,
            }}>
              <Text style={{ color: item.role === 'user' ? 'white' : 'black', fontSize: 16 }}>{item.content}</Text>
            </View>
          )}
        />
      </Animated.View>

      {loading && <ActivityIndicator size='large' color='#007AFF' style={{ marginVertical: 10 }} />}

      <View style={{
        flexDirection: 'row',
        alignItems: 'center',
        padding: 14,
        backgroundColor: darkMode ? '#1e1e1e' : 'white',
        borderRadius: 30,
        marginBottom: 10,
        shadowColor: '#000',
        shadowOpacity: 0.2,
        shadowOffset: { width: 0, height: 4 },
        shadowRadius: 6,
        elevation: 8,
      }}>
        <TextInput
          style={{ flex: 1, padding: 10, fontSize: 16, color: darkMode ? 'white' : 'black' }}
          placeholder='Type a message...'
          placeholderTextColor={darkMode ? '#888' : '#555'}
          value={input}
          onChangeText={setInput}
        />
        <TouchableOpacity onPress={sendMessage} style={{ marginLeft: 10 }}>
          <AntDesign name='arrowup' size={32} color='#007AFF' />
        </TouchableOpacity>
      </View>
    </View>
  );
};

// Home Screen Component
const HomeScreen = ({ navigation }) => {
  return (
    <View style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        <Image source={require('./assets/profile.png')} style={styles.profileImage} />
        <Text style={styles.title}>Welcome to My Portfolio</Text>
        <Text style={styles.subtitle}>Sanaullah - BSCS Student at Abasyn University, Islamabad Campus</Text>

        <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('About')}>
          <Icon name="user" size={20} color="#fff" />
          <Text style={styles.buttonText}>About Me</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('Skills')}>
          <Icon name="cogs" size={20} color="#fff" />
          <Text style={styles.buttonText}>Skills</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('Projects')}>
          <Icon name="folder" size={20} color="#fff" />
          <Text style={styles.buttonText}>Projects</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('Contact')}>
          <Icon name="envelope" size={20} color="#fff" />
          <Text style={styles.buttonText}>Contact Me</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('Chatbot')}>
          <Icon name="comments" size={20} color="#fff" />
          <Text style={styles.buttonText}>Chat with Me</Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
};

// About Screen Component
const AboutScreen = () => {
  return (
    <View style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        <Text style={styles.title}>About Me</Text>
        <Text style={styles.text}>
          Hi, I'm Sanaullah, a BSCS student at Abasyn University, Islamabad Campus. I'm passionate about programming, software development, and learning new technologies.
        </Text>
      </ScrollView>
    </View>
  );
};

// Skills Screen Component
const SkillsScreen = () => {
  const skills = [
    { name: 'React Native', icon: 'mobile' },
    { name: 'JavaScript', icon: 'code' },
    { name: 'Python', icon: 'python' },
    { name: 'Web Development', icon: 'globe' },
    { name: 'UI/UX Design', icon: 'paint-brush' },
  ];

  return (
    <View style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        <Text style={styles.title}>Skills</Text>
        {skills.map((skill, index) => (
          <View key={index} style={styles.skillCard}>
            <Icon name={skill.icon} size={30} color="#007bff" />
            <Text style={styles.skillText}>{skill.name}</Text>
          </View>
        ))}
      </ScrollView>
    </View>
  );
};

// Projects Screen Component
const ProjectsScreen = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const projects = [
    { name: 'Portfolio App', description: 'A mobile portfolio app built with React Native.' },
    { name: 'E-commerce Website', description: 'A full-stack e-commerce website using MERN stack.' },
    { name: 'Chat Application', description: 'A real-time chat app using Firebase and React.' },
  ];

  const filteredProjects = projects.filter((project) =>
    project.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    project.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <View style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        <Text style={styles.title}>Projects</Text>
        <TextInput
          style={styles.searchBar}
          placeholder="Search projects..."
          placeholderTextColor="#888"
          value={searchQuery}
          onChangeText={setSearchQuery}
        />
        {filteredProjects.map((project, index) => (
          <View key={index} style={styles.projectCard}>
            <Text style={styles.projectTitle}>{project.name}</Text>
            <Text style={styles.projectDescription}>{project.description}</Text>
          </View>
        ))}
      </ScrollView>
    </View>
  );
};

// Contact Screen Component
const ContactScreen = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');

  const handleSubmit = () => {
    if (!name || !email || !message) {
      Alert.alert('Error', 'Please fill in all fields.');
      return;
    }
    Alert.alert('Success', 'Your message has been sent!');
    setName('');
    setEmail('');
    setMessage('');
  };

  return (
    <View style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        <Text style={styles.title}>Contact Me</Text>
        <TextInput
          style={styles.input}
          placeholder="Your Name"
          placeholderTextColor="#888"
          value={name}
          onChangeText={setName}
        />
        <TextInput
          style={styles.input}
          placeholder="Your Email"
          placeholderTextColor="#888"
          value={email}
          onChangeText={setEmail}
          keyboardType="email-address"
        />
        <TextInput
          style={[styles.input, { height: 100 }]}
          placeholder="Your Message"
          placeholderTextColor="#888"
          value={message}
          onChangeText={setMessage}
          multiline
        />
        <TouchableOpacity style={styles.button} onPress={handleSubmit}>
          <Text style={styles.buttonText}>Send Message</Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
};

// CV Screen Component
const CVScreen = () => {
  const downloadCV = () => {
    Alert.alert('Download', 'Your CV has been downloaded!');
  };

  return (
    <View style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        <Text style={styles.title}>My CV</Text>
        <Text style={styles.text}>
          Download my CV to learn more about my qualifications and experiences.
        </Text>
        <TouchableOpacity style={styles.button} onPress={downloadCV}>
          <Icon name="download" size={20} color="#fff" />
          <Text style={styles.buttonText}>Download CV</Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
};

// Experiences Screen Component
const ExperiencesScreen = () => {
  const experiences = [
    { title: 'Software Developer Intern', company: 'Tech Solutions Inc.', duration: 'Jan 2023 - Present' },
    { title: 'Freelance Web Developer', company: 'Self-Employed', duration: 'Jun 2022 - Dec 2022' },
  ];

  return (
    <View style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        <Text style={styles.title}>Experiences</Text>
        {experiences.map((exp, index) => (
          <View key={index} style={styles.experienceCard}>
            <Text style={styles.experienceTitle}>{exp.title}</Text>
            <Text style={styles.experienceCompany}>{exp.company}</Text>
            <Text style={styles.experienceDuration}>{exp.duration}</Text>
          </View>
        ))}
      </ScrollView>
    </View>
  );
};

// Main App Component
export default function App() {
  const [darkMode, setDarkMode] = useState(false);

  const theme = darkMode ? DarkTheme : DefaultTheme;

  return (
    <NavigationContainer theme={theme}>
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="About" component={AboutScreen} />
        <Stack.Screen name="Skills" component={SkillsScreen} />
        <Stack.Screen name="Projects" component={ProjectsScreen} />
        <Stack.Screen name="Contact" component={ContactScreen} />
        <Stack.Screen name="Chatbot" component={ChatbotScreen} />
        <Stack.Screen name="CV" component={CVScreen} />
        <Stack.Screen name="Experiences" component={ExperiencesScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

// Styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f4f4f4',
    padding: 20,
  },
  scrollContainer: {
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  profileImage: {
    width: 150,
    height: 150,
    borderRadius: 75,
    marginBottom: 20,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 16,
    color: '#666',
    marginBottom: 30,
    textAlign: 'center',
  },
  button: {
    flexDirection: 'row',
    backgroundColor: '#007bff',
    padding: 15,
    borderRadius: 5,
    alignItems: 'center',
    marginBottom: 15,
    width: '80%',
    justifyContent: 'center',
  },
  buttonText: {
    color: '#fff',
    fontSize: 18,
    marginLeft: 10,
  },
  text: {
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
    marginBottom: 20,
  },
  skillCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 10,
    marginBottom: 10,
    width: '80%',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 3,
  },
  skillText: {
    color: '#333',
    fontSize: 18,
    marginLeft: 10,
  },
  projectCard: {
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 10,
    marginBottom: 15,
    width: '80%',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 3,
  },
  projectTitle: {
    color: '#333',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  projectDescription: {
    color: '#666',
    fontSize: 14,
  },
  searchBar: {
    width: '80%',
    padding: 10,
    backgroundColor: '#fff',
    borderRadius: 5,
    marginBottom: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 3,
  },
  input: {
    width: '80%',
    padding: 10,
    backgroundColor: '#fff',
    borderRadius: 5,
    marginBottom: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 3,
  },
  experienceCard: {
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 10,
    marginBottom: 15,
    width: '80%',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 3,
  },
  experienceTitle: {
    color: '#333',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  experienceCompany: {
    color: '#666',
    fontSize: 16,
    marginBottom: 5,
  },
  experienceDuration: {
    color: '#888',
    fontSize: 14,
  },
});